
package project;
import java.awt.Component;
import java.awt.Image;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableCellRenderer;
public class InformasiBudaya extends javax.swing.JFrame {

    /**
     * Creates new form InformasiBudaya
     */
    private DefaultTableModel tableModel;
    
    public InformasiBudaya() {
        initComponents();
         initializeTable(); 
         loadTableData();
        ;
    }
   private void initializeTable() {
        // Pastikan tabel sudah memiliki model DefaultTableModel
        if (table.getModel() == null) {
            table.setModel(new DefaultTableModel());
        }

        tableModel = (DefaultTableModel) table.getModel();  // Ambil model tabel yang sudah ada

        // Menambahkan kolom jika belum ada
        if (tableModel.getColumnCount() == 0) {
            tableModel.addColumn("ID");
            tableModel.addColumn("Gambar");
            tableModel.addColumn("Deskripsi");
        }

        // Mengatur kolom
        String[] columnNames = {"ID", "Gambar", "Deskripsi"};
        tableModel.setColumnIdentifiers(columnNames);  // Menetapkan nama kolom ke tableModel

        // Set renderer untuk kolom "Gambar"
        table.getColumn("Gambar").setCellRenderer(new ImageRenderer());
        table.getColumnModel().getColumn(1).setPreferredWidth(200); // Lebar kolom Gambar
        table.setRowHeight(100);  // Tinggi baris gambar
    }


         
    private void loadTableData() {
    try (Connection conn = Koneksi.getConnection()) {
        String query = "SELECT * FROM informasi_budaya";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);

        tableModel.setRowCount(0);  // Bersihkan tabel sebelum memuat data baru

        // Memasukkan data ke dalam tabel
        while (rs.next()) {
            String imagePath = rs.getString("gambar"); // Path gambar (String)
            ImageIcon imageIcon = new ImageIcon(imagePath);  // Membuat ImageIcon dari path

            tableModel.addRow(new Object[] {
                rs.getInt("id"),  // ID
                imageIcon,  // Gambar (sekarang berisi ImageIcon)
                rs.getString("deskripsi")  // Deskripsi
            });
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
    }
}

   public class ImageRenderer extends JLabel implements TableCellRenderer {

    private static final int MAX_WIDTH = 150;  // Lebar maksimal gambar
    private static final int MAX_HEIGHT = 100; // Tinggi maksimal gambar

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        if (value != null && value instanceof ImageIcon) {
            // Ambil ImageIcon yang sudah ada
            ImageIcon icon = (ImageIcon) value;

            // Mengambil gambar asli
            Image image = icon.getImage();

            // Menyesuaikan ukuran gambar agar sesuai dengan batas maksimal
            Image resizedImage = image.getScaledInstance(MAX_WIDTH, MAX_HEIGHT, Image.SCALE_SMOOTH);

            // Menampilkan gambar yang telah disesuaikan ukurannya
            setIcon(new ImageIcon(resizedImage));
            setText("");  // Menghapus teks (karena hanya gambar yang ditampilkan)
        } else {
            setIcon(null);
            setText("No Image");
        }
        return this;
    }
}



   private ImageIcon loadImage(String imagePath) {
//    ImageIcon icon = null;
//
//    // Cek apakah path gambar valid dan dapat diakses
//    File file = new File(imagePath);
//    
//    // Jika path gambar relatif, pastikan menggunakan path relatif terhadap lokasi proyek
//    if (!file.exists()) {
//        // Jika gambar tidak ditemukan, tampilkan pesan kesalahan dengan path absolut
//        JOptionPane.showMessageDialog(null, "Gambar tidak ditemukan di path: " + file.getAbsolutePath());
//    } else if (file.isFile()) {
//        // Gambar ditemukan, buat ImageIcon dari path
//        icon = new ImageIcon(file.getAbsolutePath()); // Menggunakan absolute path
//    }
//
//    return icon;
ImageIcon icon;
    File file = new File(imagePath);
    if (!file.exists() || !file.isFile()) {
        icon = new ImageIcon(getClass().getResource("/path/to/default/icon.png"));
    } else {
        icon = new ImageIcon(file.getAbsolutePath());
    }
    return icon;
}
    
   private void handleTambah() {
    String gambar = txtGambar.getText();
    String deskripsi = txtDeskripsi.getText();

    if (!gambar.isEmpty() && !deskripsi.isEmpty()) {
        try (Connection conn = Koneksi.getConnection()) {
            String query = "INSERT INTO informasi_budaya (gambar, deskripsi) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, gambar);  // Menyimpan path gambar
            stmt.setString(2, deskripsi);  // Menyimpan deskripsi
            stmt.executeUpdate();

            // Mendapatkan ID yang baru saja ditambahkan
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);  // Mendapatkan ID yang baru saja dimasukkan
                JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");

                // Memuat data ulang ke dalam tabel
                loadTableData();

                // Mengosongkan field input
                clearFields();

                // Menambahkan gambar dan deskripsi ke dalam tabel
//                ImageIcon imageIcon = new ImageIcon(gambar);  // Menggunakan path untuk membuat ImageIcon
//                Object[] rowData = new Object[3];  // Tiga kolom: ID, Gambar, dan Deskripsi
//                rowData[0] = id;  // Menambahkan ID ke dalam tabel
//                rowData[1] = imageIcon;  // Menambahkan gambar
//                rowData[2] = deskripsi;  // Menambahkan deskripsi
//                tableModel.addRow(rowData);  // Menambahkan data baru ke tabel
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(null, "Mohon isi semua field!");
    }
}


    private void handleEdit() {
        int id = Integer.parseInt(txtId.getText());
        String gambar = txtGambar.getText();
        String deskripsi = txtDeskripsi.getText();

        if (!gambar.isEmpty() && !deskripsi.isEmpty()) {
            try (Connection conn = Koneksi.getConnection()) {
                String query = "UPDATE informasi_budaya SET gambar = ?, deskripsi = ? WHERE id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, gambar);
                stmt.setString(2, deskripsi);
                stmt.setInt(3, id);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil diupdate!");
                loadTableData();
                clearFields();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Mohon isi semua field!");
        }
    }

    private void handleHapus() {
        int id = Integer.parseInt(txtId.getText());
        int confirm = JOptionPane.showConfirmDialog(null, "Apakah Anda yakin ingin menghapus data ini?");
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = Koneksi.getConnection()) {
                String query = "DELETE FROM informasi_budaya WHERE id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, id);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                loadTableData();
                clearFields();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        }
    }

    private void clearFields() {
        txtId.setText("");
        txtGambar.setText("");
        txtDeskripsi.setText("");
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtGambar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtDeskripsi = new javax.swing.JTextField();
        btnTambah = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        btnPilihGambar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 153, 51));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("ID");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("GAMBAR");

        txtGambar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGambarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("DESKRIPSI");

        btnTambah.setFont(new java.awt.Font("ROG Fonts", 0, 12)); // NOI18N
        btnTambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/Icon Tambah.png"))); // NOI18N
        btnTambah.setText("TAMBAH");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnHapus.setFont(new java.awt.Font("ROG Fonts", 0, 12)); // NOI18N
        btnHapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/Icon Hapus.png"))); // NOI18N
        btnHapus.setText("HAPUS");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        btnEdit.setFont(new java.awt.Font("ROG Fonts", 0, 12)); // NOI18N
        btnEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/Icon Update.png"))); // NOI18N
        btnEdit.setText("EDIT");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(102, 102, 102));
        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\fikri\\Downloads\\Desain tanpa judul (2).png")); // NOI18N
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(835, 0, -1, -1));

        jLabel5.setBackground(new java.awt.Color(102, 102, 102));
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\fikri\\Downloads\\Desain tanpa judul (2).png")); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, -1, -1));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Penambahan Informasi Budaya");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(377, 66, -1, -1));

        jButton2.setBackground(new java.awt.Color(102, 102, 102));
        jButton2.setFont(new java.awt.Font("Rockwell Extra Bold", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\fikri\\Downloads\\prev (180 x 180 piksel).png")); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        btnPilihGambar.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        btnPilihGambar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/Icon Simpan.png"))); // NOI18N
        btnPilihGambar.setText("Pilih Gambar");
        btnPilihGambar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPilihGambarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(txtId)
                                .addComponent(txtGambar)
                                .addComponent(btnPilihGambar, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
                                .addComponent(txtDeskripsi))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnEdit)
                                .addGap(18, 18, 18)
                                .addComponent(btnHapus)))
                        .addGap(60, 60, 60)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtGambar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(btnPilihGambar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDeskripsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTambah)
                            .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 970, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtGambarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGambarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGambarActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        // TODO add your handling code here:
        handleHapus();
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        // TODO add your handling code here:
       handleTambah();
        
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnPilihGambarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPilihGambarActionPerformed

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Gambar (JPG, PNG, GIF,JPEG)", "jpg","png", "gif","jpeg"));
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            txtGambar.setText(selectedFile.getAbsolutePath());
        }
    }//GEN-LAST:event_btnPilihGambarActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        // TODO add your handling code here:
        handleEdit();
    }//GEN-LAST:event_btnEditActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        String userRole = "admin"; // Menetapkan peran pengguna
        MainPageAdmin mainPage = new MainPageAdmin(userRole); // Meneruskan peran ke MainPageUser
        mainPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InformasiBudaya.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InformasiBudaya.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InformasiBudaya.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InformasiBudaya.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InformasiBudaya().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnPilihGambar;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtDeskripsi;
    private javax.swing.JTextField txtGambar;
    private javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
