/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package project;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.*;
import javax.swing.table.TableCellRenderer;

public class InformasiBudayaUser extends javax.swing.JFrame {

    /**
     * Creates new form InformasiBudayaUser
     */
    private DefaultTableModel tableModel;
    public InformasiBudayaUser() {
        initComponents();
        initializeTable();
        loadTableData();
        table.addMouseListener(new java.awt.event.MouseAdapter() {
    @Override
    public void mouseClicked(java.awt.event.MouseEvent evt) {
        int row = table.getSelectedRow();
        if (row != -1) {
            int id = (int) tableModel.getValueAt(row, 0);
            String gambarPath = (String) tableModel.getValueAt(row, 1);
            String deskripsi = (String) tableModel.getValueAt(row, 2);

            showDetailFrame(id, gambarPath, deskripsi); // Panggil fungsi untuk menampilkan detail
        }
    }
});

        
    }
     private void initializeTable() {
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Gambar");
        tableModel.addColumn("Deskripsi");
        table.setModel(tableModel);

        // Menambahkan renderer untuk kolom gambar
        table.getColumn("Gambar").setCellRenderer(new ImageRenderer());
        table.getColumnModel().getColumn(1).setPreferredWidth(200); // Atur lebar kolom gambar
        table.setRowHeight(100); // Atur tinggi baris untuk menampilkan gambar
    }

    private void loadTableData() {
        try (Connection conn = Koneksi.getConnection()) {
            String query = "SELECT * FROM informasi_budaya";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            tableModel.setRowCount(0); // Bersihkan tabel sebelum memuat data baru

            while (rs.next()) {
                int id = rs.getInt("id");
                String gambarPath = rs.getString("gambar");
                String deskripsi = rs.getString("deskripsi");

                // Tambahkan data ke tabel
                tableModel.addRow(new Object[]{
                    id,  // ID
                    gambarPath,  // Path gambar (ditangani oleh renderer)
                    deskripsi  // Deskripsi
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }

    private static class ImageRenderer extends JLabel implements TableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            if (value != null) {
                String imagePath = value.toString();
                ImageIcon icon = loadImage(imagePath);

                if (icon != null) {
                    Image image = icon.getImage();
                    Image scaledImage = image.getScaledInstance(150, 100, Image.SCALE_SMOOTH); // Ukuran gambar
                    setIcon(new ImageIcon(scaledImage));
                    setText(""); // Hapus teks
                } else {
                    setIcon(null);
                    setText("Gambar Tidak Ditemukan");
                }
            } else {
                setIcon(null);
                setText("No Image");
            }
            return this;
        }

        private ImageIcon loadImage(String imagePath) {
            File file = new File(imagePath);
            if (file.exists() && file.isFile()) {
                return new ImageIcon(imagePath);
            }
            return null;
        }
    }
    private void showDetailFrame(int id, String gambarPath, String deskripsi) {
    JFrame detailFrame = new JFrame("Detail Informasi Budaya");

    // Komponen gambar
    JLabel labelGambar = new JLabel();
    ImageIcon icon = new ImageRenderer().loadImage(gambarPath); // Gunakan metode dari ImageRenderer
    if (icon != null) {
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(300, 200, Image.SCALE_SMOOTH);
        labelGambar.setIcon(new ImageIcon(scaledImage));
    } else {
        labelGambar.setText("Gambar Tidak Ditemukan");
        labelGambar.setHorizontalAlignment(SwingConstants.CENTER);
    }

    // Komponen deskripsi
    JTextArea textAreaDeskripsi = new JTextArea(deskripsi);
    textAreaDeskripsi.setWrapStyleWord(true);
    textAreaDeskripsi.setLineWrap(true);
    textAreaDeskripsi.setEditable(false);

    // Tata letak
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(labelGambar, BorderLayout.CENTER);
    panel.add(new JScrollPane(textAreaDeskripsi), BorderLayout.SOUTH);

    // Atur frame
    detailFrame.setSize(400, 400);
    detailFrame.add(panel);
    detailFrame.setLocationRelativeTo(null); // Pusatkan frame di layar
    detailFrame.setVisible(true);
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 153, 51));

        jPanel2.setBackground(new java.awt.Color(51, 153, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 2, 24)); // NOI18N
        jLabel1.setText("Informasi Budaya");

        jButton1.setBackground(new java.awt.Color(102, 153, 255));
        jButton1.setFont(new java.awt.Font("Rockwell Extra Bold", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\fikri\\Downloads\\prev (180 x 180 piksel).png")); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jButton1)
                .addGap(106, 106, 106)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 14, Short.MAX_VALUE)))
                .addContainerGap())
        );

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    String userRole = "user"; // Menetapkan peran pengguna
    MainPageUser mainPage = new MainPageUser(userRole); // Meneruskan peran ke MainPageUser
    mainPage.setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InformasiBudayaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InformasiBudayaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InformasiBudayaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InformasiBudayaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                InformasiBudayaUser frame = new InformasiBudayaUser();
//                frame.setVisible(true);
                new InformasiBudayaUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
